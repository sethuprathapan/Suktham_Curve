$(function() {
    function validateSalutation() {
        var selectedSalutation = $('#salutation').val();
        if (selectedSalutation === "") {
            $('.error-salutation').text('Please select a salutation').css('color', 'red');
            return false;
        } else {
            $('.error-salutation').text('');
            return true;
        }
    }

    function validateEmail() {
        var email = $('#email').val().trim();
        var gmailRegex = /^[a-zA-Z0-9._%+-]+@gmail\.com$/;
        if (gmailRegex.test(email)) {
            $('#email').css('border-color', 'green');
            $('.error').hide();
            return true;
        } else {
            $('#email').css('border-color', 'red');
            $('.error').show();
            return false;
        }
    }

    function validateFirstName() {
        var inp = $('#fname').val().trim();
        var textRegex = /^[a-zA-Z]+$/;
        if (!inp) {
            $('.error-fname').text('Enter first name').addClass('invalid-text-color');
            return false;
        } else if (!textRegex.test(inp)) {
            $('.error-fname').text('First name should only contain letters.').addClass('invalid-text-color');
            return false;
        } else if (inp.length <= 3) {
            $('.error-fname').text('First name should contain more than 3 letters').addClass('invalid-text-color');
            return false;
        } else {
            $('.error-fname').text('').removeClass('invalid-text-color');
            return true;
        }
    }

    function validateLastName() {
        var inp = $('#lname').val().trim();
        var textRegex = /^[a-zA-Z]+$/;
        if (!inp) {
            $('.error-lname').text('Enter last name').addClass('invalid-text-color');
            return false;
        } else if (!textRegex.test(inp)) {
            $('.error-lname').text('Last name should only contain letters.').addClass('invalid-text-color');
            return false;
        } else {
            $('.error-lname').text('').removeClass('invalid-text-color');
            return true;
        }
    }

    function validatePhone() {
        var inp = $('#phn').val().trim();
        var regularEx = /^\d{10}$/;
        if (!inp) {
            $('.error-phn').text('Enter Your Phone Number ...').css('color', 'red');
            return false;
        } else if (regularEx.test(inp)) {
            $('.error-phn').text('').css('color', '');
            return true;
        } else {
            $('.error-phn').text('Enter valid Phone Number ...').css('color', 'red');
            return false;
        }
    }

    function validateAddress() {
        var inp = $('#Address').val().trim();
        if (!inp) {
            $('.error-add').text('This field cannot be empty').css('color', 'red');
            return false;
        } else {
            $('.error-add').text('');
            return true;
        }
    }

    function validateCity() {
        var inp = $('#city').val().trim();
        if (!inp) {
            $('.error-city').text('This field cannot be empty').css('color', 'red');
            return false;
        } else {
            $('.error-city').text('');
            return true;
        }
    }

    function validateZip() {
        var inp = $('#zipcode').val().trim();
        var zipRegex = /^\d{6}(-\d{4})?$/;
        if (!inp) {
            $('.error-zip').text('Enter your ZIP code').css('color', 'red');
            return false;
        } else if (zipRegex.test(inp)) {
            $('.error-zip').text('');
            return true;
        } else {
            $('.error-zip').text('Enter a valid ZIP code (e.g., 12345 or 12345-6789)').css('color', 'red');
            return false;
        }
    }

    function validateGender() {
        var selectedGender = $('#gender').val();
        if (selectedGender === "select gender") {
            $('.error-gender').text('Please select a gender').css('color', 'red');
            return false;
        } else {
            $('.error-gender').text('');
            return true;
        }
    }

    function validateDOB() {
        var dob = $('#dob').val();
        var today = new Date();
        var selectedDate = new Date(dob);
        if (!dob) {
            $('.error-dob').text('Please enter your date of birth').css('color', 'red');
            return false;
        } else if (selectedDate > today) {
            $('.error-dob').text('Date of birth cannot be in the future').css('color', 'red');
            return false;
        } else {
            $('.error-dob').text('');
            return true;
        }
    }

    // Individual input validation
    $('#email').on('blur', validateEmail);
    $('#fname').on('blur', validateFirstName);
    $('#lname').on('blur', validateLastName);
    $('#phn').on('blur', validatePhone);
    $('#Address').on('blur', validateAddress);
    $('#city').on('blur', validateCity);
    $('#zipcode').on('blur', validateZip);
    $('#gender').on('blur change', validateGender);
    $('#dob').on('blur', validateDOB);
    $('#salutation').on('blur', validateSalutation);

    $('form').on('submit', function(e) {
        e.preventDefault(); // Prevent form submission
        var isValid = validateEmail() && validateFirstName() && validateLastName() &&
                      validatePhone() && validateAddress() && validateCity() &&
                      validateZip() && validateGender() && validateDOB() &&
                      validateSalutation(); 
        
                      if (isValid) {
                        this.submit();
                    } else {
                        // Find the first error element and scroll to it
                        var firstError = $('.error').filter(function() {
                            return $(this).text() !== '';
                        }).first();
            
                        if (firstError.length) {
                            $('html, body').animate({
                                scrollTop: firstError.closest('div').offset().top
                            }, 500);
                        }}
    });
});
